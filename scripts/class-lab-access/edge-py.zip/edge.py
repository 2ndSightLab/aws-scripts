from boto3 import client as boto3_client
import json

lambda_client = boto3_client('lambda')

def lambda_handler(event, context):
    function='function:CLS-2SL3000-montreal-lambda-RegistrationLambda-1SGBY2U6CM8L'
    invoke_response = lambda_client.invoke(FunctionName="another_lambda_",
                                           InvocationType='Event',
                                           Payload=json.dumps(event))
    print(invoke_response)
